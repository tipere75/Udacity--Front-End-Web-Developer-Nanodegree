# Weather-Journal App Project

## Overview
In this project, I created an asynchronous web app that uses Web API and user data to dynamically update the UI.
